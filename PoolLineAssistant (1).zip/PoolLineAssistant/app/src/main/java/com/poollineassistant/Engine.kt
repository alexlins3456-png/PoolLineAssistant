package com.poollineassistant

import android.graphics.PointF
import android.graphics.RectF
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

/** Cena compartilhada entre overlay e simulador. Posições normalizadas (0..1) dentro da mesa. */
object Scene {
    val cue = PointF(0.22f, 0.5f)
    val balls = mutableListOf(PointF(0.6f, 0.42f))
    var angle = -0.1f // direção da tacada, em radianos
    var pocket = -1   // caçapa-alvo da bola 1 (0..5) ou -1 = mira manual

    fun toJson(): String = JSONObject().apply {
        put("cx", cue.x.toDouble()); put("cy", cue.y.toDouble()); put("a", angle.toDouble()); put("p", pocket)
        put("b", JSONArray().also { arr -> balls.forEach { arr.put(JSONArray().put(it.x.toDouble()).put(it.y.toDouble())) } })
    }.toString()

    fun fromJson(s: String): Boolean = try {
        val o = JSONObject(s)
        cue.set(o.getDouble("cx").toFloat(), o.getDouble("cy").toFloat())
        angle = o.getDouble("a").toFloat(); pocket = o.getInt("p")
        val arr = o.getJSONArray("b")
        balls.clear()
        for (i in 0 until arr.length()) { val p = arr.getJSONArray(i); balls.add(PointF(p.getDouble(0).toFloat(), p.getDouble(1).toFloat())) }
        true
    } catch (e: Exception) { false }
}

enum class Role { AIM, BOUNCE, OBJECT, CUE_AFTER }
class Seg(val a: PointF, val b: PointF, val role: Role)
class Mark(val at: PointF, val angleDeg: Float)
class Trajectory(val segs: List<Seg>, val marks: List<Mark>, val ghost: PointF?)

/**
 * Simulador geométrico independente. Só usa as posições informadas pelo usuário:
 * não lê o jogo. Sem spin nem atrito (serve para treinar ângulos).
 */
object TrajectoryEngine {
    fun compute(cue: PointF, dirX: Float, dirY: Float, balls: List<PointF>, area: RectF,
                r: Float, maxLen: Float, maxBounces: Int): Trajectory {
        val segs = ArrayList<Seg>(); val marks = ArrayList<Mark>()
        val n = hypot(dirX, dirY)
        if (n < 1e-6f) return Trajectory(segs, marks, null)
        var dx = dirX / n; var dy = dirY / n
        val minX = area.left + r; val maxX = area.right - r
        val minY = area.top + r; val maxY = area.bottom - r
        var px = cue.x; var py = cue.y
        var left = maxLen; var bounces = 0; var first = true

        // Distância até a tabela para o CENTRO da bola; true = parede vertical.
        fun wall(x: Float, y: Float, ux: Float, uy: Float): Pair<Float, Boolean> {
            val tx = if (ux > 1e-6f) (maxX - x) / ux else if (ux < -1e-6f) (minX - x) / ux else Float.MAX_VALUE
            val ty = if (uy > 1e-6f) (maxY - y) / uy else if (uy < -1e-6f) (minY - y) / uy else Float.MAX_VALUE
            return if (tx <= ty) tx.coerceAtLeast(0f) to true else ty.coerceAtLeast(0f) to false
        }

        while (left > 0.5f) {
            val (tw, vert) = wall(px, py, dx, dy)
            var tb = Float.MAX_VALUE; var hit: PointF? = null
            for (b in balls) {
                val t = rayCircle(px, py, dx, dy, b.x, b.y, 2 * r)
                if (t != null && t < tb) { tb = t; hit = b }
            }
            val role = if (first) Role.AIM else Role.BOUNCE

            if (hit != null && tb < tw && tb < left) {
                // Colisão bola x bola: a bola alvo sai pela linha dos centros; a branca segue pela tangente.
                val cx = px + dx * tb; val cy = py + dy * tb
                segs += Seg(PointF(px, py), PointF(cx, cy), role)
                var nx = hit.x - cx; var ny = hit.y - cy
                val nl = hypot(nx, ny); nx /= nl; ny /= nl
                val cs = (dx * nx + dy * ny).coerceIn(-1f, 1f)
                marks += Mark(PointF(cx, cy), Math.toDegrees(acos(cs).toDouble()).toFloat())
                val rest = left - tb
                val tObj = min(rest, wall(hit.x, hit.y, nx, ny).first)
                segs += Seg(PointF(hit.x, hit.y), PointF(hit.x + nx * tObj, hit.y + ny * tObj), Role.OBJECT)
                val tx = dx - cs * nx; val ty = dy - cs * ny
                val tl = hypot(tx, ty)
                if (tl > 1e-3f) {
                    val ux = tx / tl; val uy = ty / tl
                    val tc = min(rest * 0.5f, wall(cx, cy, ux, uy).first)
                    segs += Seg(PointF(cx, cy), PointF(cx + ux * tc, cy + uy * tc), Role.CUE_AFTER)
                }
                return Trajectory(segs, marks, PointF(cx, cy))
            }

            val t = min(tw, left)
            val ex = px + dx * t; val ey = py + dy * t
            segs += Seg(PointF(px, py), PointF(ex, ey), role)
            left -= t
            if (t < tw || bounces >= maxBounces) break
            val incidence = acos((if (vert) abs(dx) else abs(dy)).coerceIn(0f, 1f).toDouble())
            marks += Mark(PointF(ex, ey), Math.toDegrees(incidence).toFloat())
            if (vert) dx = -dx else dy = -dy
            px = ex; py = ey; bounces++; first = false
        }
        return Trajectory(segs, marks, null)
    }

    private fun rayCircle(px: Float, py: Float, dx: Float, dy: Float, cx: Float, cy: Float, rad: Float): Float? {
        val fx = px - cx; val fy = py - cy
        val b = fx * dx + fy * dy
        val disc = b * b - (fx * fx + fy * fy - rad * rad)
        if (disc < 0f) return null
        val t = -b - sqrt(disc)
        return if (t > 1e-3f) t else null
    }
}
