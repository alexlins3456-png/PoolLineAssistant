package com.poollineassistant

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/**
 * Camada que desenha as projeções. No overlay fica transparente sobre o jogo;
 * no simulador desenha a própria mesa. Os toques só são tratados nos modos EDIT/CALIBRATE.
 */
class ProjectionView(ctx: Context, private val overlay: Boolean) : View(ctx) {
    enum class Mode { PLAY, EDIT, CALIBRATE }

    var mode = Mode.PLAY
        set(v) { field = v; invalidate() }

    /** Modo "Colocar": 1º toque = bola branca, próximos toques = bolas alvo. */
    var placing = false
        set(v) { field = v; placeStep = 0; if (v) { Scene.balls.clear(); Scene.pocket = -1 }; invalidate() }
    private var placeStep = 0

    private val d = ctx.resources.displayMetrics.density
    private val table = RectF()
    private val pen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 14 * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }
    private var drag = NONE

    companion object { private const val NONE = -1; private const val CUE = 0; private const val AIM = 1; private const val BALL0 = 10; private const val CORNER0 = 100; private const val POCKET0 = 200 }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val saved = if (overlay) Prefs.table else null
        if (saved != null) {
            table.set(saved[0] * w, saved[1] * h, saved[2] * w, saved[3] * h)
        } else {
            val m = (if (overlay) 24 else 56) * d
            var tw = w - 2 * m; var th = tw / 2f
            if (th > h - 2 * m) { th = h - 2 * m; tw = th * 2f }
            table.set((w - tw) / 2, (h - th) / 2, (w + tw) / 2, (h + th) / 2)
        }
    }

    fun addBall() { if (Scene.balls.size < 15) Scene.balls.add(PointF(0.5f + 0.02f * Scene.balls.size, 0.5f)); persist(); invalidate() }
    fun clearBalls() { Scene.balls.clear(); Scene.pocket = -1; persist(); invalidate() }

    private fun persist() = Prefs.setSlot(9, Scene.toJson())

    /** Monta o triângulo padrão (15 bolas) no ponto da mesa e a branca na cabeceira. */
    fun rack() {
        if (table.width() < 50f) return
        val r = table.width() * 0.01125f * Prefs.ballScalePct / 100f
        val ru = r / table.width(); val rv = r / table.height()
        Scene.cue.set(0.25f, 0.5f); Scene.pocket = -1
        Scene.balls.clear()
        for (row in 0 until 5) for (j in 0..row)
            Scene.balls.add(PointF(0.72f + row * 1.74f * ru, 0.5f + (j - row / 2f) * 2.05f * rv))
        val a = toPx(Scene.cue); val b = toPx(Scene.balls[0])
        Scene.angle = atan2(b.y - a.y, b.x - a.x)
        placing = false; persist(); invalidate()
    }

    private fun placeAt(x: Float, y: Float) {
        if (placeStep == 0) fromPx(Scene.cue, x, y)
        else if (Scene.balls.size < 15) { val n = PointF(); fromPx(n, x, y); Scene.balls.add(n) }
        placeStep++; aimAtPocket(); persist(); invalidate()
    }
    fun removeBall() { if (Scene.balls.isNotEmpty()) Scene.balls.removeAt(Scene.balls.size - 1); if (Scene.balls.isEmpty()) Scene.pocket = -1; persist(); invalidate() }

    private fun toPx(n: PointF) = PointF(table.left + n.x * table.width(), table.top + n.y * table.height())
    private fun fromPx(n: PointF, x: Float, y: Float) =
        n.set(((x - table.left) / table.width()).coerceIn(0f, 1f), ((y - table.top) / table.height()).coerceIn(0f, 1f))
    private fun handle(): PointF { val c = toPx(Scene.cue); return PointF(c.x + cos(Scene.angle) * 70 * d, c.y + sin(Scene.angle) * 70 * d) }
    private fun corners() = listOf(PointF(table.left, table.top), PointF(table.right, table.top), PointF(table.right, table.bottom), PointF(table.left, table.bottom))

    private fun pockets() = listOf(
        PointF(table.left, table.top), PointF((table.left + table.right) / 2, table.top), PointF(table.right, table.top),
        PointF(table.left, table.bottom), PointF((table.left + table.right) / 2, table.bottom), PointF(table.right, table.bottom))

    /** Calcula a direção da tacada para a bola 1 ir à caçapa escolhida, usando as posições informadas por você. */
    private fun aimAtPocket() {
        if (Scene.pocket < 0 || Scene.balls.isEmpty() || table.width() < 50f) return
        val r = table.width() * 0.01125f * Prefs.ballScalePct / 100f
        val b = toPx(Scene.balls[0]); val k = pockets()[Scene.pocket]; val c = toPx(Scene.cue)
        val l = hypot(k.x - b.x, k.y - b.y); if (l < 1f) return
        val gx = b.x - (k.x - b.x) / l * 2 * r; val gy = b.y - (k.y - b.y) / l * 2 * r   // bola fantasma
        Scene.angle = atan2(gy - c.y, gx - c.x)
    }

    override fun onDraw(cv: Canvas) {
        if (table.width() < 50f) return
        val r = table.width() * 0.01125f * Prefs.ballScalePct / 100f   // raio proporcional ao comprimento da mesa
        val col = Prefs.color
        if (!overlay) drawTable(cv)
        val cue = toPx(Scene.cue)
        val balls = Scene.balls.map { toPx(it) }
        val tr = TrajectoryEngine.compute(cue, cos(Scene.angle), sin(Scene.angle), balls, table, r,
            table.width() * 3f * Prefs.lengthPct / 100f, Prefs.bounces)

        pen.style = Paint.Style.STROKE; pen.strokeWidth = 2.5f * d; pen.color = col
        for (s in tr.segs) {
            val aim = s.role == Role.AIM
            if (if (aim) !Prefs.aimOn else !Prefs.trajOn) continue
            pen.pathEffect = if (s.role == Role.BOUNCE || s.role == Role.CUE_AFTER) DashPathEffect(floatArrayOf(14 * d, 9 * d), 0f) else null
            pen.strokeWidth = 7f * d; pen.alpha = 50; cv.drawLine(s.a.x, s.a.y, s.b.x, s.b.y, pen)   // brilho
            pen.strokeWidth = 2.5f * d; pen.alpha = 255; cv.drawLine(s.a.x, s.a.y, s.b.x, s.b.y, pen)
        }
        pen.pathEffect = null
        if (Prefs.aimOn) tr.ghost?.let { cv.drawCircle(it.x, it.y, r, pen) }   // "bola fantasma" no ponto de contato
        if (Prefs.anglesOn) { label.color = col; for (m in tr.marks) cv.drawText("${m.angleDeg.roundToInt()}°", m.at.x, m.at.y - r - 6 * d, label) }

        // caçapas e linha da bola 1 até a caçapa escolhida, com ângulo de corte e dificuldade
        pockets().forEachIndexed { i, k ->
            if (mode != Mode.PLAY || i == Scene.pocket) {
                pen.style = Paint.Style.STROKE; pen.pathEffect = null; pen.strokeWidth = 2f * d
                pen.color = if (i == Scene.pocket) col else Color.argb(150, 255, 255, 255)
                cv.drawCircle(k.x, k.y, if (i == Scene.pocket) 2.2f * r else 1.6f * r, pen)
            }
        }
        if (Scene.pocket >= 0 && balls.isNotEmpty()) {
            val b = balls[0]; val k = pockets()[Scene.pocket]
            val ux = k.x - b.x; val uy = k.y - b.y; val l = hypot(ux, uy)
            if (l > 1f) {
                pen.style = Paint.Style.STROKE; pen.color = col; pen.strokeWidth = 2f * d
                pen.pathEffect = DashPathEffect(floatArrayOf(4 * d, 8 * d), 0f); cv.drawLine(b.x, b.y, k.x, k.y, pen); pen.pathEffect = null
                val cs = (cos(Scene.angle) * ux / l + sin(Scene.angle) * uy / l).coerceIn(-1f, 1f)
                val cut = Math.toDegrees(acos(cs).toDouble()).roundToInt()
                val nivel = if (cut < 20) "Fácil" else if (cut < 45) "Médio" else if (cut < 75) "Difícil" else "Quase impossível"
                label.color = col; cv.drawText("Corte $cut° · $nivel", b.x, b.y + r + 20 * d, label)
            }
        }

        val fill = if (overlay) Color.argb(45, 255, 255, 255) else Color.WHITE
        ball(cv, cue, r, fill, col, null)
        balls.forEachIndexed { i, b -> ball(cv, b, r, if (overlay) fill else Color.rgb(255, 170, 0), col, if (mode != Mode.PLAY) "${i + 1}" else null) }

        pen.style = Paint.Style.STROKE; pen.color = Color.WHITE; pen.strokeWidth = 2f * d
        if (mode == Mode.EDIT) { val h = handle(); cv.drawCircle(h.x, h.y, 14 * d, pen) }
        if (mode == Mode.CALIBRATE) {
            pen.pathEffect = DashPathEffect(floatArrayOf(12 * d, 8 * d), 0f); cv.drawRect(table, pen); pen.pathEffect = null
            corners().forEach { cv.drawCircle(it.x, it.y, 14 * d, pen) }
        }
        if (overlay && mode != Mode.PLAY) {
            label.color = Color.WHITE
            cv.drawText(if (placing) (if (placeStep == 0) "COLOCAR: toque onde está a bola branca" else "COLOCAR: toque cada bola (${Scene.balls.size}) e desligue Colocar ao terminar")
                        else if (mode == Mode.EDIT) "EDITAR: arraste as bolas e o anel · toque numa caçapa para mirar nela"
                        else "CALIBRAR: arraste os cantos até a borda interna da mesa", width / 2f, 28 * d, label)
        }
    }

    private fun ball(cv: Canvas, c: PointF, r: Float, fill: Int, stroke: Int, tag: String?) {
        pen.pathEffect = null
        pen.style = Paint.Style.FILL; pen.color = fill; cv.drawCircle(c.x, c.y, r, pen)
        pen.style = Paint.Style.STROKE; pen.color = stroke; pen.strokeWidth = 2f * d; cv.drawCircle(c.x, c.y, r, pen)
        if (tag != null) { label.color = stroke; cv.drawText(tag, c.x, c.y + 5 * d, label) }
    }

    private fun drawTable(cv: Canvas) {
        pen.style = Paint.Style.FILL
        pen.color = Color.rgb(94, 60, 30)
        cv.drawRoundRect(table.left - 18 * d, table.top - 18 * d, table.right + 18 * d, table.bottom + 18 * d, 18 * d, 18 * d, pen)
        pen.color = Color.rgb(10, 108, 62); cv.drawRect(table, pen)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (mode == Mode.PLAY) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (placing && mode == Mode.EDIT) { placeAt(e.x, e.y); return true }
                drag = pick(e.x, e.y)
                if (drag >= POCKET0) {   // toque numa caçapa: calcula a mira até ela (toque de novo para desligar)
                    Scene.pocket = if (Scene.pocket == drag - POCKET0) -1 else drag - POCKET0
                    aimAtPocket(); drag = NONE; invalidate()
                }
            }
            MotionEvent.ACTION_MOVE -> { move(e.x, e.y); invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == Mode.CALIBRATE && overlay)
                    Prefs.table = floatArrayOf(table.left / width, table.top / height, table.right / width, table.bottom / height)
                if (mode == Mode.EDIT && drag != NONE) persist()
                drag = NONE
            }
        }
        return true
    }

    private fun pick(x: Float, y: Float): Int {
        var best = NONE; var bestD = 40 * d
        fun test(id: Int, p: PointF) { val dd = hypot(p.x - x, p.y - y); if (dd < bestD) { bestD = dd; best = id } }
        if (mode == Mode.CALIBRATE) corners().forEachIndexed { i, p -> test(CORNER0 + i, p) }
        else {
            test(AIM, handle()); test(CUE, toPx(Scene.cue))
            Scene.balls.forEachIndexed { i, b -> test(BALL0 + i, toPx(b)) }
            pockets().forEachIndexed { i, k -> test(POCKET0 + i, k) }
        }
        return best
    }

    private fun move(x: Float, y: Float) {
        when {
            drag == CUE -> { fromPx(Scene.cue, x, y); aimAtPocket() }
            drag == AIM -> { val c = toPx(Scene.cue); Scene.angle = atan2(y - c.y, x - c.x); Scene.pocket = -1 }
            drag in BALL0 until CORNER0 -> Scene.balls.getOrNull(drag - BALL0)?.let { fromPx(it, x, y); aimAtPocket() }
            drag >= CORNER0 -> {
                val n = RectF(table)
                when (drag - CORNER0) {
                    0 -> { n.left = x; n.top = y }
                    1 -> { n.right = x; n.top = y }
                    2 -> { n.right = x; n.bottom = y }
                    else -> { n.left = x; n.bottom = y }
                }
                if (n.width() > 80 * d && n.height() > 40 * d) table.set(n)
            }
        }
    }
}
