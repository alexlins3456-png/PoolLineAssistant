package com.poollineassistant

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import kotlin.reflect.KProperty

/** Configurações persistentes, compartilhadas por overlay, simulador e tela de ajustes. */
object Prefs {
    private lateinit var sp: SharedPreferences
    val PALETTE = intArrayOf(Color.rgb(0, 230, 118), Color.rgb(255, 235, 59), Color.rgb(0, 229, 255), Color.rgb(255, 64, 129), Color.WHITE)

    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("pla", Context.MODE_PRIVATE) }
    fun register(l: SharedPreferences.OnSharedPreferenceChangeListener) = sp.registerOnSharedPreferenceChangeListener(l)
    fun unregister(l: SharedPreferences.OnSharedPreferenceChangeListener) = sp.unregisterOnSharedPreferenceChangeListener(l)

    private class BoolP(val k: String, val d: Boolean) {
        operator fun getValue(t: Any?, p: KProperty<*>): Boolean = sp.getBoolean(k, d)
        operator fun setValue(t: Any?, p: KProperty<*>, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    }
    private class IntP(val k: String, val d: Int) {
        operator fun getValue(t: Any?, p: KProperty<*>): Int = sp.getInt(k, d)
        operator fun setValue(t: Any?, p: KProperty<*>, v: Int) { sp.edit().putInt(k, v).apply() }
    }

    var aimOn by BoolP("aimOn", true)          // linha de mira
    var trajOn by BoolP("trajOn", true)        // trajetórias projetadas (tabelas e bola alvo)
    var anglesOn by BoolP("anglesOn", true)    // ângulos de colisão
    var acknowledged by BoolP("ack", false)    // usuário confirmou que é ferramenta de treino
    var lengthPct by IntP("len", 50)
    var bounces by IntP("bounces", 3)
    var ballScalePct by IntP("ball", 100)
    var lineAlphaPct by IntP("lineAlpha", 70)
    var panelAlphaPct by IntP("panelAlpha", 90)
    var colorIdx by IntP("color", 0)
    var panelX by IntP("px", 40)
    var panelY by IntP("py", 40)
    val color: Int get() = PALETTE[colorIdx.coerceIn(0, PALETTE.lastIndex)]

    /** Mesa calibrada no overlay, como frações da tela: left, top, right, bottom. */
    var table: FloatArray?
        get() = sp.getString("table", null)?.split(",")?.mapNotNull { it.toFloatOrNull() }?.takeIf { it.size == 4 }?.toFloatArray()
        set(v) { sp.edit().apply { if (v == null) remove("table") else putString("table", v.joinToString(",")) }.apply() }
}
