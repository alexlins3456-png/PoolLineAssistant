package com.poollineassistant

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        val pad = Ui.dp(this, 20)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun add(v: View) = col.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@SettingsActivity, 10) })

        add(Ui.text(this, "Configurações", 22f, Color.WHITE, true))
        add(Ui.row(this,
            Ui.chip(this, "Mira", Prefs.aimOn) { Prefs.aimOn = it.isSelected },
            Ui.chip(this, "Trajetória", Prefs.trajOn) { Prefs.trajOn = it.isSelected },
            Ui.chip(this, "Ângulos", Prefs.anglesOn) { Prefs.anglesOn = it.isSelected }))
        add(Ui.seek(this, "Comprimento das linhas %", 10, 100, Prefs.lengthPct) { Prefs.lengthPct = it })
        add(Ui.seek(this, "Quiques nas tabelas", 0, 5, Prefs.bounces) { Prefs.bounces = it })
        add(Ui.seek(this, "Tamanho da bola %", 60, 150, Prefs.ballScalePct) { Prefs.ballScalePct = it })
        add(Ui.seek(this, "Opacidade das linhas %", 20, 80, Prefs.lineAlphaPct) { Prefs.lineAlphaPct = it })
        add(Ui.seek(this, "Opacidade do painel %", 30, 100, Prefs.panelAlphaPct) { Prefs.panelAlphaPct = it })
        add(Ui.text(this, "Cor das projeções", 11f, Color.LTGRAY))
        add(Ui.colors(this, Prefs.colorIdx) { Prefs.colorIdx = it })
        add(Ui.btn(this, "Restaurar calibração da mesa") {
            Prefs.table = null; Toast.makeText(this, "Reinicie o overlay para aplicar.", Toast.LENGTH_SHORT).show()
        })
        add(Ui.text(this, "Ferramenta de treino: as projeções vêm de um simulador independente e dependem das posições que você informa. " +
            "Não há leitura de memória, injeção de código nem automação de jogadas.", 12f, Color.GRAY))
        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(col) })
    }
}
