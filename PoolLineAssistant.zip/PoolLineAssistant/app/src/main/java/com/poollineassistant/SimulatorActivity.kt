package com.poollineassistant

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.content.Intent

/** Simulador de trajetórias: mesma engine do overlay, com mesa própria. Arraste a branca, as bolas e o anel. */
class SimulatorActivity : Activity() {
    private lateinit var view: ProjectionView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        view = ProjectionView(this, false).apply { mode = ProjectionView.Mode.EDIT }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(Ui.dp(this@SimulatorActivity, 6), Ui.dp(this@SimulatorActivity, 6), 0, 0) }
        listOf(
            Ui.chip(this, "Mira", Prefs.aimOn) { Prefs.aimOn = it.isSelected; view.invalidate() },
            Ui.chip(this, "Trajetória", Prefs.trajOn) { Prefs.trajOn = it.isSelected; view.invalidate() },
            Ui.chip(this, "Ângulos", Prefs.anglesOn) { Prefs.anglesOn = it.isSelected; view.invalidate() },
            Ui.btn(this, "+Bola") { view.addBall() },
            Ui.btn(this, "−Bola") { view.removeBall() },
            Ui.btn(this, "Config.") { startActivity(Intent(this, SettingsActivity::class.java)) },
            Ui.btn(this, "Voltar") { finish() }
        ).forEach { bar.addView(it, LinearLayout.LayoutParams(-2, -2).apply { setMargins(Ui.dp(this@SimulatorActivity, 3), 0, Ui.dp(this@SimulatorActivity, 3), 0) }) }
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(Ui.BG); addView(view)
            addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        })
    }

    override fun onResume() { super.onResume(); view.invalidate() }
}
