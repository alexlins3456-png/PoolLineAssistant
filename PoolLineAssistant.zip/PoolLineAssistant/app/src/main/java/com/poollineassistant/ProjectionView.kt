package com.poollineassistant

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/**
 * Camada que desenha as projeções. No overlay fica transparente sobre o jogo;
 * no simulador desenha a própria mesa. Os toques só são tratados nos modos EDIT/CALIBRATE.
 */
class ProjectionView(ctx: Context, private val overlay: Boolean) : View(ctx) {
    enum class Mode { PLAY, EDIT, CALIBRATE }

    var mode = Mode.PLAY
        set(v) { field = v; invalidate() }

    private val d = ctx.resources.displayMetrics.density
    private val table = RectF()
    private val pen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 14 * d; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }
    private var drag = NONE

    companion object { private const val NONE = -1; private const val CUE = 0; private const val AIM = 1; private const val BALL0 = 10; private const val CORNER0 = 100 }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val saved = if (overlay) Prefs.table else null
        if (saved != null) {
            table.set(saved[0] * w, saved[1] * h, saved[2] * w, saved[3] * h)
        } else {
            val m = (if (overlay) 24 else 56) * d
            var tw = w - 2 * m; var th = tw / 2f
            if (th > h - 2 * m) { th = h - 2 * m; tw = th * 2f }
            table.set((w - tw) / 2, (h - th) / 2, (w + tw) / 2, (h + th) / 2)
        }
    }

    fun addBall() { if (Scene.balls.size < 5) Scene.balls.add(PointF(0.5f + 0.03f * Scene.balls.size, 0.5f)); invalidate() }
    fun removeBall() { if (Scene.balls.isNotEmpty()) Scene.balls.removeAt(Scene.balls.size - 1); invalidate() }

    private fun toPx(n: PointF) = PointF(table.left + n.x * table.width(), table.top + n.y * table.height())
    private fun fromPx(n: PointF, x: Float, y: Float) =
        n.set(((x - table.left) / table.width()).coerceIn(0f, 1f), ((y - table.top) / table.height()).coerceIn(0f, 1f))
    private fun handle(): PointF { val c = toPx(Scene.cue); return PointF(c.x + cos(Scene.angle) * 70 * d, c.y + sin(Scene.angle) * 70 * d) }
    private fun corners() = listOf(PointF(table.left, table.top), PointF(table.right, table.top), PointF(table.right, table.bottom), PointF(table.left, table.bottom))

    override fun onDraw(cv: Canvas) {
        if (table.width() < 50f) return
        val r = table.width() * 0.01125f * Prefs.ballScalePct / 100f   // raio proporcional ao comprimento da mesa
        val col = Prefs.color
        if (!overlay) drawTable(cv)
        val cue = toPx(Scene.cue)
        val balls = Scene.balls.map { toPx(it) }
        val tr = TrajectoryEngine.compute(cue, cos(Scene.angle), sin(Scene.angle), balls, table, r,
            table.width() * 3f * Prefs.lengthPct / 100f, Prefs.bounces)

        pen.style = Paint.Style.STROKE; pen.strokeWidth = 2.5f * d; pen.color = col
        for (s in tr.segs) {
            val aim = s.role == Role.AIM
            if (if (aim) !Prefs.aimOn else !Prefs.trajOn) continue
            pen.pathEffect = if (s.role == Role.BOUNCE || s.role == Role.CUE_AFTER) DashPathEffect(floatArrayOf(14 * d, 9 * d), 0f) else null
            cv.drawLine(s.a.x, s.a.y, s.b.x, s.b.y, pen)
        }
        pen.pathEffect = null
        if (Prefs.aimOn) tr.ghost?.let { cv.drawCircle(it.x, it.y, r, pen) }   // "bola fantasma" no ponto de contato
        if (Prefs.anglesOn) { label.color = col; for (m in tr.marks) cv.drawText("${m.angleDeg.roundToInt()}°", m.at.x, m.at.y - r - 6 * d, label) }

        val fill = if (overlay) Color.argb(45, 255, 255, 255) else Color.WHITE
        ball(cv, cue, r, fill, col, null)
        balls.forEachIndexed { i, b -> ball(cv, b, r, if (overlay) fill else Color.rgb(255, 170, 0), col, if (mode != Mode.PLAY) "${i + 1}" else null) }

        pen.style = Paint.Style.STROKE; pen.color = Color.WHITE; pen.strokeWidth = 2f * d
        if (mode == Mode.EDIT) { val h = handle(); cv.drawCircle(h.x, h.y, 14 * d, pen) }
        if (mode == Mode.CALIBRATE) {
            pen.pathEffect = DashPathEffect(floatArrayOf(12 * d, 8 * d), 0f); cv.drawRect(table, pen); pen.pathEffect = null
            corners().forEach { cv.drawCircle(it.x, it.y, 14 * d, pen) }
        }
        if (overlay && mode != Mode.PLAY) {
            label.color = Color.WHITE
            cv.drawText(if (mode == Mode.EDIT) "EDITAR: arraste a branca, as bolas e o anel para mirar"
                        else "CALIBRAR: arraste os cantos até a borda interna da mesa", width / 2f, 28 * d, label)
        }
    }

    private fun ball(cv: Canvas, c: PointF, r: Float, fill: Int, stroke: Int, tag: String?) {
        pen.pathEffect = null
        pen.style = Paint.Style.FILL; pen.color = fill; cv.drawCircle(c.x, c.y, r, pen)
        pen.style = Paint.Style.STROKE; pen.color = stroke; pen.strokeWidth = 2f * d; cv.drawCircle(c.x, c.y, r, pen)
        if (tag != null) { label.color = stroke; cv.drawText(tag, c.x, c.y + 5 * d, label) }
    }

    private fun drawTable(cv: Canvas) {
        pen.style = Paint.Style.FILL
        pen.color = Color.rgb(94, 60, 30)
        cv.drawRoundRect(table.left - 18 * d, table.top - 18 * d, table.right + 18 * d, table.bottom + 18 * d, 18 * d, 18 * d, pen)
        pen.color = Color.rgb(10, 108, 62); cv.drawRect(table, pen)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (mode == Mode.PLAY) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> drag = pick(e.x, e.y)
            MotionEvent.ACTION_MOVE -> { move(e.x, e.y); invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == Mode.CALIBRATE && overlay)
                    Prefs.table = floatArrayOf(table.left / width, table.top / height, table.right / width, table.bottom / height)
                drag = NONE
            }
        }
        return true
    }

    private fun pick(x: Float, y: Float): Int {
        var best = NONE; var bestD = 40 * d
        fun test(id: Int, p: PointF) { val dd = hypot(p.x - x, p.y - y); if (dd < bestD) { bestD = dd; best = id } }
        if (mode == Mode.CALIBRATE) corners().forEachIndexed { i, p -> test(CORNER0 + i, p) }
        else {
            test(AIM, handle()); test(CUE, toPx(Scene.cue))
            Scene.balls.forEachIndexed { i, b -> test(BALL0 + i, toPx(b)) }
        }
        return best
    }

    private fun move(x: Float, y: Float) {
        when {
            drag == CUE -> fromPx(Scene.cue, x, y)
            drag == AIM -> { val c = toPx(Scene.cue); Scene.angle = atan2(y - c.y, x - c.x) }
            drag in BALL0 until CORNER0 -> Scene.balls.getOrNull(drag - BALL0)?.let { fromPx(it, x, y) }
            drag >= CORNER0 -> {
                val n = RectF(table)
                when (drag - CORNER0) {
                    0 -> { n.left = x; n.top = y }
                    1 -> { n.right = x; n.top = y }
                    2 -> { n.right = x; n.bottom = y }
                    else -> { n.left = x; n.bottom = y }
                }
                if (n.width() > 80 * d && n.height() > 40 * d) table.set(n)
            }
        }
    }
}
