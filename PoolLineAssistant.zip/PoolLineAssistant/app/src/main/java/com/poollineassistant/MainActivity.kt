package com.poollineassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() { super.onResume(); render() }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun render() {
        val canDraw = Settings.canDrawOverlays(this)
        val running = OverlayService.running
        val pad = Ui.dp(this, 20)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        fun add(v: View) = col.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = Ui.dp(this@MainActivity, 8) })
        fun big(label: String, onClick: () -> Unit) = Ui.btn(this, label, onClick).apply {
            textSize = 15f; val p = Ui.dp(this@MainActivity, 14); setPadding(p, p, p, p)
        }

        add(Ui.text(this, "Pool Line Assistant", 24f, Color.WHITE, true))
        add(Ui.text(this, "Modo Overlay · ferramenta de treino", 13f, Ui.ACCENT))
        add(Ui.text(this, "As linhas são calculadas por um simulador independente, a partir das posições que VOCÊ informa ou ajusta manualmente. " +
            "O app não lê a memória do jogo, não injeta código, não altera nem automatiza o 8 Ball Pool e não faz jogadas por você. " +
            "A sobreposição usa a permissão oficial \"Exibir sobre outros apps\" do Android.", 13f, Color.LTGRAY))
        add(Ui.text(this, "Atenção: os termos do jogo podem restringir ferramentas de terceiros durante partidas online. " +
            "O risco de uso é seu; o Simulador funciona fora do jogo.", 12f, Color.rgb(255, 200, 80)))
        add(Ui.chip(this, "Entendi: é uma ferramenta de treino e as projeções dependem das posições que eu informo", Prefs.acknowledged) { Prefs.acknowledged = it.isSelected })

        add(big(if (canDraw) "✓ Permissão de sobreposição concedida" else "1. Permitir exibição sobre outros apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        add(big(if (running) "Parar overlay" else "2. Iniciar overlay") {
            when {
                running -> startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
                !canDraw -> toast("Conceda primeiro a permissão de sobreposição.")
                !Prefs.acknowledged -> toast("Confirme o aviso de ferramenta de treino.")
                else -> startForegroundService(Intent(this, OverlayService::class.java))
            }
            window.decorView.postDelayed({ render() }, 500)
        })
        add(big("3. Abrir 8 Ball Pool") {
            packageManager.getLaunchIntentForPackage("com.miniclip.eightballpool")?.let { startActivity(it) } ?: toast("8 Ball Pool não encontrado.")
        })
        add(big("Abrir simulador") { startActivity(Intent(this, SimulatorActivity::class.java)) })
        add(big("Configurações") { startActivity(Intent(this, SettingsActivity::class.java)) })

        add(Ui.text(this, "Como usar: com o jogo aberto, toque em Calibrar e arraste os cantos até as bordas internas da mesa. " +
            "Em Editar, posicione a bola branca, as bolas alvo e o anel de mira. Volte para o modo normal (desligue Editar) " +
            "para devolver os toques ao jogo. A bolinha \"PLA\" aparece ao minimizar o painel.", 12f, Color.GRAY))

        setContentView(ScrollView(this).apply { setBackgroundColor(Ui.BG); addView(col) })
    }
}
