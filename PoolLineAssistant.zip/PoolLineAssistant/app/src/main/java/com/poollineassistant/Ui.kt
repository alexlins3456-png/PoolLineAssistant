package com.poollineassistant

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.roundToInt

/** Helpers de UI feitos só com views do framework (sem depender de tema/AppCompat; funciona em Service). */
object Ui {
    val BG = Color.rgb(18, 22, 28)
    val ACCENT = Color.rgb(0, 230, 118)

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).roundToInt()

    fun box(color: Int, radius: Float, oval: Boolean = false, stroke: Int = 0, strokeW: Int = 0) = GradientDrawable().apply {
        shape = if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
        setColor(color); cornerRadius = radius
        if (strokeW > 0) setStroke(strokeW, stroke)
    }

    fun text(c: Context, s: String, size: Float = 12f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(c).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    fun restyle(tv: TextView) {
        val on = tv.isSelected
        tv.setTextColor(if (on) Color.BLACK else Color.WHITE)
        tv.background = box(if (on) ACCENT else Color.argb(60, 255, 255, 255), dp(tv.context, 14).toFloat())
    }

    /** Botão de alternar: usa isSelected como estado. */
    fun chip(c: Context, label: String, on: Boolean, onClick: (TextView) -> Unit) = text(c, label, 12f).apply {
        gravity = Gravity.CENTER
        setPadding(dp(c, 8), dp(c, 6), dp(c, 8), dp(c, 6))
        isSelected = on; restyle(this)
        setOnClickListener { isSelected = !isSelected; restyle(this); onClick(this) }
    }

    /** Botão de ação (sem estado). */
    fun btn(c: Context, label: String, onClick: () -> Unit) = chip(c, label, false) { it.isSelected = false; restyle(it); onClick() }

    fun row(c: Context, vararg v: View) = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        for (x in v) addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(c, 2), dp(c, 2), dp(c, 2), dp(c, 2))
        })
    }

    fun seek(c: Context, label: String, min: Int, max: Int, value: Int, onChange: (Int) -> Unit): View {
        val title = text(c, "$label: $value", 11f, Color.LTGRAY)
        val bar = SeekBar(c)
        bar.max = max - min; bar.progress = value - min
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) {
                title.text = "$label: ${p + min}"
                if (user) onChange(p + min)
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        return LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; addView(title); addView(bar) }
    }

    fun colors(c: Context, selected: Int, onPick: (Int) -> Unit): View {
        val holder = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val dots = ArrayList<View>()
        fun refresh(sel: Int) = dots.forEachIndexed { i, v ->
            v.background = box(Prefs.PALETTE[i], 0f, true, Color.WHITE, if (i == sel) dp(c, 3) else 0)
        }
        Prefs.PALETTE.indices.forEach { i ->
            val v = View(c); dots.add(v)
            v.setOnClickListener { onPick(i); refresh(i) }
            holder.addView(v, LinearLayout.LayoutParams(dp(c, 26), dp(c, 26)).apply { setMargins(dp(c, 5), dp(c, 3), dp(c, 5), dp(c, 3)) })
        }
        refresh(selected)
        return holder
    }
}
