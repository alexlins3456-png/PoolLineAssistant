package com.poollineassistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.view.WindowManager.LayoutParams as LP
import android.widget.*
import com.poollineassistant.ProjectionView.Mode
import kotlin.math.hypot
import kotlin.math.min

/**
 * Modo Overlay: usa a permissão oficial "Exibir sobre outros apps" (SYSTEM_ALERT_WINDOW).
 * Duas janelas: (1) camada de projeção, normalmente sem toque (os toques passam para o jogo);
 * (2) painel flutuante arrastável / minimizável em "bolha".
 * Nada aqui lê memória, injeta código, altera ou automatiza o jogo.
 */
class OverlayService : Service() {
    companion object {
        const val ACTION_STOP = "com.poollineassistant.STOP"
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var projLp: LP
    private lateinit var panelLp: LP
    private lateinit var bubble: TextView
    private lateinit var body: View
    private lateinit var editChip: TextView
    private lateinit var calChip: TextView
    private var proj: ProjectionView? = null
    private var root: FrameLayout? = null
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> applyPrefs() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (proj == null) {
            Prefs.init(this)
            goForeground()   // precisa ser chamado logo após startForegroundService
            if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY }
            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            buildWindows()
            Prefs.register(prefListener)
            running = true
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("pla", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "pla")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Pool Line Assistant")
            .setContentText("Overlay de treino ativo")
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null as Icon?, "Parar", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    }

    private fun lp(w: Int, h: Int, touchable: Boolean) = LP(
        w, h, LP.TYPE_APPLICATION_OVERLAY,
        LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS or (if (touchable) 0 else LP.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        layoutInDisplayCutoutMode = LP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun buildWindows() {
        val p = ProjectionView(this, true)
        projLp = lp(-1, -1, false)          // adicionada primeiro => fica ABAIXO do painel
        wm.addView(p, projLp); proj = p
        val r = buildPanel()
        panelLp = lp(-2, -2, true).apply { x = Prefs.panelX; y = Prefs.panelY }
        wm.addView(r, panelLp); root = r
        applyPrefs()
    }

    private fun applyPrefs() {
        val p = proj ?: return; val r = root ?: return
        // Android 12+: janelas com alpha > 0,8 bloqueiam toques que atravessam o overlay. Por isso o teto de 0,8.
        projLp.alpha = Prefs.lineAlphaPct.coerceIn(20, 80) / 100f
        panelLp.alpha = Prefs.panelAlphaPct.coerceIn(30, 100) / 100f
        wm.updateViewLayout(p, projLp); wm.updateViewLayout(r, panelLp)
        p.invalidate()
    }

    private fun setMode(m: Mode) {
        val p = proj ?: return
        p.mode = m
        projLp.flags = if (m == Mode.PLAY) projLp.flags or LP.FLAG_NOT_TOUCHABLE else projLp.flags and LP.FLAG_NOT_TOUCHABLE.inv()
        wm.updateViewLayout(p, projLp)
        editChip.isSelected = m == Mode.EDIT; calChip.isSelected = m == Mode.CALIBRATE
        Ui.restyle(editChip); Ui.restyle(calChip)
    }

    private fun toggle(expand: Boolean) {
        body.visibility = if (expand) View.VISIBLE else View.GONE
        bubble.visibility = if (expand) View.GONE else View.VISIBLE
        if (!expand) setMode(Mode.PLAY)   // ao minimizar, os toques voltam para o jogo
    }

    private fun open(cls: Class<*>) = startActivity(Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    private fun buildPanel(): FrameLayout {
        val c = this
        val frame = FrameLayout(c)

        bubble = Ui.text(c, "PLA", 12f, Color.BLACK, true).apply {
            gravity = Gravity.CENTER; background = Ui.box(Ui.ACCENT, 0f, oval = true); visibility = View.GONE
        }
        frame.addView(bubble, FrameLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)))
        drag(bubble) { toggle(true) }

        val title = Ui.text(c, "☰ Pool Line Assistant", 12f, Color.WHITE, true).apply { setPadding(Ui.dp(c, 4), Ui.dp(c, 6), Ui.dp(c, 4), Ui.dp(c, 6)) }
        drag(title) {}
        val header = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Ui.btn(c, "–") { toggle(false) })
        header.addView(Ui.btn(c, "✕") { stopSelf() })

        editChip = Ui.chip(c, "Editar", false) { setMode(if (it.isSelected) Mode.EDIT else Mode.PLAY) }
        calChip = Ui.chip(c, "Calibrar", false) { setMode(if (it.isSelected) Mode.CALIBRATE else Mode.PLAY) }

        val list = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        list.addView(Ui.row(c,
            Ui.chip(c, "Mira", Prefs.aimOn) { Prefs.aimOn = it.isSelected },
            Ui.chip(c, "Trajetória", Prefs.trajOn) { Prefs.trajOn = it.isSelected },
            Ui.chip(c, "Ângulos", Prefs.anglesOn) { Prefs.anglesOn = it.isSelected }))
        list.addView(Ui.seek(c, "Comprimento %", 10, 100, Prefs.lengthPct) { Prefs.lengthPct = it })
        list.addView(Ui.seek(c, "Opacidade das linhas %", 20, 80, Prefs.lineAlphaPct) { Prefs.lineAlphaPct = it })
        list.addView(Ui.seek(c, "Opacidade do painel %", 30, 100, Prefs.panelAlphaPct) { Prefs.panelAlphaPct = it })
        list.addView(Ui.colors(c, Prefs.colorIdx) { Prefs.colorIdx = it })
        list.addView(Ui.row(c, editChip, calChip, Ui.btn(c, "+Bola") { proj?.addBall() }, Ui.btn(c, "−Bola") { proj?.removeBall() }))
        list.addView(Ui.row(c, Ui.btn(c, "Simulador") { open(SimulatorActivity::class.java) }, Ui.btn(c, "Config.") { open(SettingsActivity::class.java) }))
        list.addView(Ui.text(c, "Ferramenta de treino. As linhas dependem das posições que você informa.", 9f, Color.GRAY))

        val h = min(Ui.dp(c, 240), (resources.displayMetrics.heightPixels * 0.6f).toInt())
        val col = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL; minimumWidth = Ui.dp(c, 300)
            setPadding(Ui.dp(c, 8), Ui.dp(c, 4), Ui.dp(c, 8), Ui.dp(c, 8))
            background = Ui.box(Color.argb(235, 18, 22, 28), Ui.dp(c, 14).toFloat(), stroke = Color.argb(90, 255, 255, 255), strokeW = Ui.dp(c, 1))
        }
        col.addView(header)
        col.addView(ScrollView(c).apply { addView(list) }, LinearLayout.LayoutParams(-1, h))
        body = col
        frame.addView(col)
        return frame
    }

    /** Arrasta a janela do painel; toque curto (sem mover) chama onTap. */
    private fun drag(v: View, onTap: () -> Unit) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        val slop = Ui.dp(this, 6)
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = panelLp.x; oy = panelLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (!moved && hypot(dx, dy) > slop) moved = true
                    if (moved) {
                        panelLp.x = (ox + dx).toInt().coerceAtLeast(0); panelLp.y = (oy + dy).toInt().coerceAtLeast(0)
                        wm.updateViewLayout(root, panelLp)
                    }
                }
                MotionEvent.ACTION_UP -> if (moved) { Prefs.panelX = panelLp.x; Prefs.panelY = panelLp.y } else onTap()
            }
            true
        }
    }

    override fun onDestroy() {
        running = false
        Prefs.unregister(prefListener)
        proj?.let { wm.removeView(it) }; root?.let { wm.removeView(it) }
        proj = null; root = null
        super.onDestroy()
    }
}
